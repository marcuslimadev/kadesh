<?php
/**
 * Teste de conectividade do backend Kadesh
 */

header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");

$response = [
    'timestamp' => date('Y-m-d H:i:s'),
    'path' => $_SERVER['REQUEST_URI'],
    'method' => $_SERVER['REQUEST_METHOD']
];

try {
    // Testar configuração do banco
    $config = require __DIR__ . '/../config/database.php';
    $response['database_config'] = [
        'host' => $config['host'],
        'dbname' => $config['dbname'], 
        'username' => $config['username']
        // Não mostrar senha por segurança
    ];
    
    // Testar conexão
    $pdo = new PDO(
        "mysql:host={$config['host']};dbname={$config['dbname']};charset=utf8mb4",
        $config['username'],
        $config['password'],
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
    
    $response['database_connection'] = 'SUCCESS';
    
    // Testar se existem tabelas
    $stmt = $pdo->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    $response['tables_found'] = count($tables);
    $response['table_list'] = $tables;
    
    // Testar tabela users especificamente
    if (in_array('users', $tables)) {
        $stmt = $pdo->query("SELECT COUNT(*) as user_count FROM users");
        $result = $stmt->fetch();
        $response['users_count'] = $result['user_count'];
        $response['users_table'] = 'EXISTS';
    } else {
        $response['users_table'] = 'NOT_FOUND';
    }
    
    // Testar sessões PHP
    session_start();
    $response['session_status'] = session_status() === PHP_SESSION_ACTIVE ? 'ACTIVE' : 'INACTIVE';
    $response['session_id'] = session_id();
    
    $response['status'] = 'SUCCESS';
    $response['message'] = 'Backend está funcionando perfeitamente!';
    
} catch (PDOException $e) {
    $response['status'] = 'DATABASE_ERROR';
    $response['database_connection'] = 'FAILED';
    $response['error'] = $e->getMessage();
} catch (Exception $e) {
    $response['status'] = 'ERROR';
    $response['error'] = $e->getMessage();
}

echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
?>