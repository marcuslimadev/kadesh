#!/bin/bash

# Kadesh Modern Stack Deployment Script
# This script helps deploy the modernized Kadesh platform

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}🚀 Kadesh Modern Stack Deployment${NC}"
echo "=================================="

# Check if we're in the right directory
if [ ! -d "modern-stack" ]; then
    echo -e "${RED}❌ Por favor, execute este script na raiz do projeto Kadesh${NC}"
    exit 1
fi

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Check dependencies
echo -e "${YELLOW}🔍 Verificando dependências...${NC}"

if ! command_exists node; then
    echo -e "${RED}❌ Node.js não encontrado. Instale Node.js 18+ primeiro.${NC}"
    exit 1
fi

if ! command_exists npm; then
    echo -e "${RED}❌ npm não encontrado. Instale npm primeiro.${NC}"
    exit 1
fi

if ! command_exists git; then
    echo -e "${RED}❌ git não encontrado. Instale git primeiro.${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Dependências verificadas${NC}"

# Setup backend
echo -e "\n${YELLOW}⚙️ Configurando backend...${NC}"
cd modern-stack/backend

if [ ! -f ".env" ]; then
    echo -e "${YELLOW}📝 Criando arquivo .env para o backend...${NC}"
    cp .env.example .env
    echo -e "${BLUE}ℹ️ Configure as variáveis de ambiente em .env antes de continuar${NC}"
fi

echo -e "${YELLOW}📦 Instalando dependências do backend...${NC}"
npm install

# Setup frontend
echo -e "\n${YELLOW}⚙️ Configurando frontend...${NC}"
cd ../frontend

if [ ! -f ".env" ]; then
    echo -e "${YELLOW}📝 Criando arquivo .env para o frontend...${NC}"
    cp .env.example .env
    echo -e "${BLUE}ℹ️ Configure as variáveis de ambiente em .env antes de continuar${NC}"
fi

echo -e "${YELLOW}📦 Instalando dependências do frontend...${NC}"
npm install

# Build frontend
echo -e "${YELLOW}🏗️ Building frontend...${NC}"
npm run build

cd ../..

echo -e "\n${GREEN}🎉 Setup concluído!${NC}"
echo "=================================="
echo -e "${BLUE}📋 Próximos passos:${NC}"
echo -e "1. Configure as variáveis de ambiente nos arquivos .env"
echo -e "2. Configure o banco PostgreSQL"
echo -e "3. Execute a migração de dados: ${YELLOW}node modern-stack/backend/scripts/migrate-data.js${NC}"
echo -e "4. Inicie o backend: ${YELLOW}cd modern-stack/backend && npm start${NC}"
echo -e "5. Para desenvolvimento frontend: ${YELLOW}cd modern-stack/frontend && npm run dev${NC}"
echo -e "\n${BLUE}🚀 Deploy:${NC}"
echo -e "1. Backend no Render: Conecte o repositório e use modern-stack/backend como root"
echo -e "2. Frontend no Vercel: Conecte o repositório e use modern-stack/frontend como root"
echo -e "\n${GREEN}✅ Tudo pronto para o deploy da versão moderna!${NC}"