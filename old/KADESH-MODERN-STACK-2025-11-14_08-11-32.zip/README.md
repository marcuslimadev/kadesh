# Migração para Arquitetura Moderna

Este documento descreve o processo de migração do sistema Kadesh da arquitetura atual (PHP + MySQL + cPanel) para uma arquitetura moderna (Node.js + PostgreSQL + Vercel + Render).

## 📋 Visão Geral

### Stack Anterior
- **Frontend**: Vue.js SPA hospedado no cPanel
- **Backend**: PHP com Apache
- **Banco de dados**: MySQL
- **Hospedagem**: cPanel/Shared Hosting

### Nova Stack
- **Frontend**: Vue.js SPA no Vercel
- **Backend**: Node.js + Express no Render
- **Banco de dados**: PostgreSQL
- **Hospedagem**: Vercel (frontend) + Render (backend)

## 🚀 Configuração do Backend

### 1. Dependências Instaladas

```json
{
  "dependencies": {
    "express": "^4.18.2",
    "cors": "^2.8.5",
    "helmet": "^7.1.0",
    "compression": "^1.7.4",
    "express-rate-limit": "^7.1.5",
    "pg": "^8.11.3",
    "bcryptjs": "^2.4.3",
    "jsonwebtoken": "^9.0.2",
    "dotenv": "^16.3.1"
  }
}
```

### 2. Estrutura de Arquivos

```
backend/
├── server.js                 # Servidor principal
├── package.json              # Dependências do projeto
├── .env.example              # Template de configuração
├── config/
│   └── database.js           # Configuração do PostgreSQL
├── routes/
│   ├── auth.js               # Rotas de autenticação
│   ├── projects.js           # Rotas de projetos
│   ├── bids.js               # Rotas de propostas
│   └── users.js              # Rotas de usuários
├── middleware/
│   └── auth.js               # Middleware de autenticação JWT
├── utils/
│   └── validators.js         # Validadores de dados
└── database/
    └── schema.sql            # Schema PostgreSQL completo
```

### 3. Configuração das Variáveis de Ambiente

Crie um arquivo `.env` baseado no `.env.example`:

```env
# Database
DB_HOST=localhost
DB_PORT=5432
DB_NAME=kadesh_modern
DB_USER=postgres
DB_PASSWORD=sua_senha

# JWT
JWT_SECRET=seu_jwt_secret_muito_secreto_aqui

# Server
PORT=3000
NODE_ENV=development

# CORS
FRONTEND_URL=http://localhost:3000

# Rate Limiting
MAX_REQUESTS_PER_MINUTE=100
```

## 📊 Banco de Dados

### Schema PostgreSQL

O novo schema inclui:

- **Tipos ENUM** para status e categorias
- **UUIDs** como chaves primárias
- **Índices otimizados** para performance
- **Triggers** para campos de updated_at
- **Extensões PostgreSQL** (uuid-ossp, pg_trgm)

### Principais Tabelas

1. **users** - Usuários (clientes e prestadores)
2. **provider_profiles** - Perfis estendidos para prestadores
3. **projects** - Projetos postados pelos clientes
4. **bids** - Propostas dos prestadores
5. **contracts** - Contratos ativos
6. **payments** - Transações de pagamento
7. **reviews** - Avaliações e comentários
8. **messages** - Sistema de mensagens
9. **notifications** - Notificações do sistema

### Migração de Dados

Para migrar dados do MySQL para PostgreSQL:

1. Execute o script `schema.sql` no PostgreSQL
2. Use ferramentas como `pg_dump` e `mysql2postgres` para migração
3. Valide a integridade dos dados migrados

## 🔐 Autenticação e Segurança

### JWT Authentication
- **Tokens** com expiração de 7 dias
- **Middleware** de autenticação para rotas protegidas
- **Passwords** com hash bcrypt (12 rounds)

### Segurança do Servidor
- **Helmet.js** para headers de segurança
- **CORS** configurado adequadamente
- **Rate limiting** para prevenir abuso
- **Validação** rigorosa de inputs
- **Sanitização** de dados de entrada

## 📡 APIs Implementadas

### Autenticação (`/api/auth`)
- `POST /register` - Registro de usuário
- `POST /login` - Login
- `GET /verify` - Verificação de token
- `POST /logout` - Logout

### Projetos (`/api/projects`)
- `GET /` - Listar projetos (com filtros)
- `GET /:id` - Detalhes do projeto
- `POST /` - Criar projeto
- `PUT /:id` - Atualizar projeto
- `DELETE /:id` - Deletar projeto
- `GET /user/my-projects` - Projetos do usuário

### Propostas (`/api/bids`)
- `GET /project/:projectId` - Propostas de um projeto
- `POST /` - Criar proposta
- `PUT /:id` - Atualizar proposta
- `DELETE /:id` - Retirar proposta
- `POST /:id/accept` - Aceitar proposta
- `GET /user/my-bids` - Propostas do usuário

### Usuários (`/api/users`)
- `GET /profile` - Perfil do usuário
- `PUT /profile` - Atualizar perfil
- `GET /:id/public` - Perfil público
- `GET /providers/search` - Buscar prestadores
- `GET /dashboard/stats` - Estatísticas do dashboard

## 🚀 Deploy

### Backend no Render

1. **Conecte o repositório** no Render
2. **Configure as variáveis de ambiente**
3. **Configure o comando de build**: `npm install`
4. **Configure o comando de start**: `npm start`
5. **Adicione o banco PostgreSQL** como addon

### Frontend no Vercel

1. **Atualize a configuração** do frontend para a nova API
2. **Configure as variáveis de ambiente** (VITE_API_URL)
3. **Deploy no Vercel** conectando o repositório
4. **Configure domínio personalizado** se necessário

## 📝 Próximos Passos

### 1. Configuração do Frontend
- Atualizar configuração da API para o Render
- Adaptar sistema de interceptors para nova URL
- Testar todas as funcionalidades

### 2. Migração de Dados
- Executar migração do MySQL para PostgreSQL
- Validar integridade dos dados
- Testar funcionalidades com dados reais

### 3. Deploy e Testes
- Deploy do backend no Render
- Deploy do frontend no Vercel
- Testes de integração completos
- Configuração de monitoramento

### 4. Funcionalidades Adicionais
- Sistema de upload de arquivos
- Notificações em tempo real
- Sistema de pagamentos integrado
- Dashboard administrativo

## 🔧 Comandos Úteis

```bash
# Instalar dependências
npm install

# Executar em desenvolvimento
npm run dev

# Executar em produção
npm start

# Criar banco de dados
psql -U postgres -c "CREATE DATABASE kadesh_modern;"

# Executar schema
psql -U postgres -d kadesh_modern -f database/schema.sql
```

## 📊 Performance e Monitoramento

### Otimizações Implementadas
- **Connection pooling** para PostgreSQL
- **Índices otimizados** para queries frequentes
- **Compressão gzip** para responses
- **Cache de queries** quando possível

### Monitoramento
- **Logs estruturados** para debugging
- **Health checks** para monitoramento
- **Error handling** centralizado
- **Métricas de performance**

---

## ✅ Status da Migração

- [x] Estrutura do backend Node.js
- [x] Configuração do PostgreSQL
- [x] APIs de autenticação
- [x] APIs de projetos e propostas
- [x] Schema completo do banco
- [x] Sistema de validação e segurança
- [ ] Configuração do frontend
- [ ] Migração de dados
- [ ] Deploy no Render/Vercel
- [ ] Testes de integração