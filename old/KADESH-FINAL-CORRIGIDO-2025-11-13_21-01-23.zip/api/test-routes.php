<?php
/**
 * Teste das rotas específicas do frontend
 */

header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// Se for OPTIONS, responder imediatamente
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$tests = [];

try {
    // Teste 1: Verificar se chegou até aqui
    $tests['script_execution'] = 'SUCCESS';
    
    // Teste 2: Verificar REQUEST_URI
    $tests['request_uri'] = $_SERVER['REQUEST_URI'];
    $tests['request_method'] = $_SERVER['REQUEST_METHOD'];
    
    // Teste 3: Verificar extração do path
    $path = $_SERVER['REQUEST_URI'];
    $path = parse_url($path, PHP_URL_PATH);
    $tests['parsed_path'] = $path;
    
    // Remover prefixo /kadesh/ se existir
    if (strpos($path, '/kadesh/') === 0) {
        $path = substr($path, 8);
        $tests['after_kadesh_removal'] = $path;
    }
    
    // Remover prefixo da api
    $apiPrefix = '/api/';
    $path = str_replace($apiPrefix, '', $path);
    $path = trim($path, '/');
    $tests['final_path'] = $path;
    
    // Teste 4: Testar conexão com banco
    $config = require __DIR__ . '/../config/database.php';
    
    $pdo = new PDO(
        "mysql:host={$config['host']};dbname={$config['dbname']};charset=utf8mb4",
        $config['username'],
        $config['password'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    
    $tests['database'] = 'CONNECTED';
    
    // Teste 5: Simular rota de health
    if ($path === 'health' || $path === 'test-routes.php' || $path === 'test-routes') {
        $tests['route_match'] = 'health';
        $tests['health_response'] = ['status' => 'ok', 'timestamp' => date('Y-m-d H:i:s')];
    }
    
    // Teste 6: Simular rota de projetos
    if ($path === 'projects') {
        $tests['route_match'] = 'projects';
        $stmt = $pdo->query("SHOW TABLES LIKE 'projects'");
        if ($stmt->rowCount() > 0) {
            $tests['projects_table'] = 'EXISTS';
        } else {
            $tests['projects_table'] = 'NOT_FOUND';
        }
    }
    
    $tests['overall_status'] = 'SUCCESS';
    
} catch (Exception $e) {
    $tests['overall_status'] = 'ERROR';
    $tests['error'] = $e->getMessage();
    $tests['error_file'] = $e->getFile();
    $tests['error_line'] = $e->getLine();
}

echo json_encode([
    'test_results' => $tests,
    'message' => 'Teste de rotas concluído'
], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
?>