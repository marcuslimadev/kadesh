<?php
return [
    'host' => 'localhost',
    'dbname' => 'seuusuario_kadesh',
    'username' => 'seuusuario_kadesh', 
    'password' => 'SuaSenhaSegura123!',
    'charset' => 'utf8mb4'
];