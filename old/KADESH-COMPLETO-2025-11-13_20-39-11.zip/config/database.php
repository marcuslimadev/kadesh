<?php
return [
    'host' => 'localhost',
    'dbname' => 'kaddeshs_novo',
    'username' => 'kaddeshs_novo', 
    'password' => 'Teste@12345',
    'charset' => 'utf8mb4'
];