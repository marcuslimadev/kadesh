/**
 * Script de inicialização da aplicação Kadesh
 * Este script aplica as configurações definidas no config.js
 * às variáveis internas da aplicação compilada.
 */

// Intercepta todas as requisições para aplicar a baseURL correta
(function() {
    'use strict';
    
    // Aguarda a configuração estar disponível
    function waitForConfig(callback) {
        if (typeof window.KADESH_CONFIG !== 'undefined') {
            callback();
        } else {
            setTimeout(() => waitForConfig(callback), 50);
        }
    }
    
    waitForConfig(function() {
        console.log('🚀 Kadesh Config carregado:', window.KADESH_CONFIG.API_BASE_URL);
        
        // Intercepta o fetch global para aplicar a baseURL
        const originalFetch = window.fetch;
        window.fetch = function(url, options) {
            // Se a URL começar com /api, substitui pela baseURL configurada
            if (typeof url === 'string' && url.startsWith('/api')) {
                url = window.KADESH_CONFIG.API_BASE_URL + url.substring(4);
                console.log('🔄 URL interceptada e corrigida para:', url);
            }
            return originalFetch.call(this, url, options);
        };
        
        // Intercepta XMLHttpRequest para axios
        const originalXHROpen = XMLHttpRequest.prototype.open;
        XMLHttpRequest.prototype.open = function(method, url, ...args) {
            // Se a URL começar com /api, substitui pela baseURL configurada
            if (typeof url === 'string' && url.startsWith('/api')) {
                url = window.KADESH_CONFIG.API_BASE_URL + url.substring(4);
                console.log('🔄 XHR URL interceptada e corrigida para:', url);
            }
            return originalXHROpen.call(this, method, url, ...args);
        };
        
        console.log('✅ Interceptadores de rede instalados com sucesso!');
    });
})();

// Função utilitária para debug
window.debugKadeshRequests = function() {
    console.log('🔍 Configuração atual:', window.KADESH_CONFIG);
    console.log('🌐 BaseURL da API:', window.KADESH_CONFIG.API_BASE_URL);
};